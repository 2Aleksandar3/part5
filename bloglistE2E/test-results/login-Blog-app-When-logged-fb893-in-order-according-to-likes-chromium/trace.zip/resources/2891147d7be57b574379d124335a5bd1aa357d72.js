import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2110a278"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2110a278"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=2110a278"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const BlogForm = ({
  addBlog,
  showNotification
}) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    addBlog({
      title,
      author,
      url
    });
    setTitle("");
    setAuthor("");
    setUrl("");
    showNotification("Blog added successfully", "success");
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "title:",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: title, name: "Title", onChange: ({
        target
      }) => setTitle(target.value) }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "author:",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: author, name: "Author", onChange: ({
        target
      }) => setAuthor(target.value) }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 33,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "url:",
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: url, name: "Url", onChange: ({
        target
      }) => setUrl(target.value) }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 39,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "submit" }, void 0, false, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
BlogForm.propTypes = {
  addBlog: PropTypes.func.isRequired,
  showNotification: PropTypes.func.isRequired
};
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/fullStackopen/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCUixPQUFPQSxTQUFTQyxnQkFBZ0I7QUFDaEMsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxXQUFXQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBUUM7QUFBaUIsTUFBTTtBQUFBQyxLQUFBO0FBQ2pELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJUCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDUSxRQUFRQyxTQUFTLElBQUlULFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNVLEtBQUtDLE1BQU0sSUFBSVgsU0FBUyxFQUFFO0FBRWpDLFFBQU1ZLGVBQWdCQyxXQUFVO0FBQzlCQSxVQUFNQyxlQUFlO0FBQ3JCWCxZQUFRO0FBQUEsTUFBRUc7QUFBQUEsTUFBT0U7QUFBQUEsTUFBUUU7QUFBQUEsSUFBSSxDQUFDO0FBQzlCSCxhQUFTLEVBQUU7QUFDWEUsY0FBVSxFQUFFO0FBQ1pFLFdBQU8sRUFBRTtBQUNUUCxxQkFBaUIsMkJBQTJCLFNBQVM7QUFBQSxFQUN2RDtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxVQUFVUSxjQUNkO0FBQUEsMkJBQUMsU0FBSTtBQUFBO0FBQUEsTUFFSCx1QkFBQyxXQUNDLE1BQUssUUFDTCxPQUFPTixPQUNQLE1BQUssU0FDTCxVQUFVLENBQUM7QUFBQSxRQUFFUztBQUFBQSxNQUFPLE1BQU1SLFNBQVNRLE9BQU9DLEtBQUssS0FKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUltRDtBQUFBLFNBTnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsU0FBSTtBQUFBO0FBQUEsTUFFSCx1QkFBQyxXQUNDLE1BQUssUUFDTCxPQUFPUixRQUNQLE1BQUssVUFDTCxVQUFVLENBQUM7QUFBQSxRQUFFTztBQUFBQSxNQUFPLE1BQU1OLFVBQVVNLE9BQU9DLEtBQUssS0FKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlvRDtBQUFBLFNBTnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsU0FBSTtBQUFBO0FBQUEsTUFFSCx1QkFBQyxXQUNDLE1BQUssUUFDTCxPQUFPTixLQUNQLE1BQUssT0FDTCxVQUFVLENBQUM7QUFBQSxRQUFFSztBQUFBQSxNQUFPLE1BQU1KLE9BQU9JLE9BQU9DLEtBQUssS0FKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlpRDtBQUFBLFNBTm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxPQTVCOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQTtBQUVKO0FBQUNYLEdBOUNLSCxVQUFRO0FBQUFlLEtBQVJmO0FBZ0ROQSxTQUFTZ0IsWUFBWTtBQUFBLEVBQ25CZixTQUFTRixVQUFVa0IsS0FBS0M7QUFBQUEsRUFDeEJoQixrQkFBa0JILFVBQVVrQixLQUFLQztBQUNuQztBQUVBLGVBQWVsQjtBQUFRLElBQUFlO0FBQUFJLGFBQUFKLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiUHJvcFR5cGVzIiwiQmxvZ0Zvcm0iLCJhZGRCbG9nIiwic2hvd05vdGlmaWNhdGlvbiIsIl9zIiwidGl0bGUiLCJzZXRUaXRsZSIsImF1dGhvciIsInNldEF1dGhvciIsInVybCIsInNldFVybCIsImhhbmRsZVN1Ym1pdCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwicHJvcFR5cGVzIiwiZnVuYyIsImlzUmVxdWlyZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcclxuXHJcbmNvbnN0IEJsb2dGb3JtID0gKHsgYWRkQmxvZyxzaG93Tm90aWZpY2F0aW9uIH0pID0+IHtcclxuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgYWRkQmxvZyh7IHRpdGxlLCBhdXRob3IsIHVybCB9KVxyXG4gICAgc2V0VGl0bGUoJycpXHJcbiAgICBzZXRBdXRob3IoJycpXHJcbiAgICBzZXRVcmwoJycpXHJcbiAgICBzaG93Tm90aWZpY2F0aW9uKCdCbG9nIGFkZGVkIHN1Y2Nlc3NmdWxseScsICdzdWNjZXNzJylcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSA+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgdGl0bGU6XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICB2YWx1ZT17dGl0bGV9XHJcbiAgICAgICAgICBuYW1lPVwiVGl0bGVcIlxyXG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRUaXRsZSh0YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIGF1dGhvcjpcclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgIHZhbHVlPXthdXRob3J9XHJcbiAgICAgICAgICBuYW1lPVwiQXV0aG9yXCJcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0QXV0aG9yKHRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgdXJsOlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgdmFsdWU9e3VybH1cclxuICAgICAgICAgIG5hbWU9XCJVcmxcIlxyXG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVcmwodGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+c3VibWl0PC9idXR0b24+XHJcbiAgICA8L2Zvcm0+XHJcbiAgKVxyXG59XHJcblxyXG5CbG9nRm9ybS5wcm9wVHlwZXMgPSB7XHJcbiAgYWRkQmxvZzogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcclxuICBzaG93Tm90aWZpY2F0aW9uOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCbG9nRm9ybSJdLCJmaWxlIjoiRjovZnVsbFN0YWNrb3Blbi9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nRm9ybS5qc3gifQ==