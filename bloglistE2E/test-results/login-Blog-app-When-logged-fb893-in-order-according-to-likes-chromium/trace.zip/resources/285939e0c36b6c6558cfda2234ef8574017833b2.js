import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2110a278"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2110a278"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=2110a278"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Blog = ({
  blog,
  handleLike,
  handleDelete,
  user
}) => {
  _s();
  const [visible, setVisible] = useState(false);
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const likeBlog = () => {
    console.log("likeBlog", blog.title);
    handleLike(blog);
  };
  const deleteBlog = () => {
    if (window.confirm(`Delete blog "${blog.title}" by ${blog.author}?`)) {
      handleDelete(blog);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, className: "blog", "data-id": blog._id, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "blog-title", children: [
      blog.title,
      " by ",
      blog.author
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, className: "toggle-button", children: visible ? "hide" : "view" }, void 0, false, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    visible && /* @__PURE__ */ jsxDEV("div", { className: "blog-details", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "blog-url", children: [
        "URL: ",
        blog.url
      ] }, void 0, true, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "blog-likes", children: [
        "likes: ",
        blog.likes
      ] }, void 0, true, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: likeBlog, className: "like-button", children: "like" }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 41,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "blog-user", children: [
        "User: ",
        blog.user ? blog.user.username : "Unknown User"
      ] }, void 0, true, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 42,
        columnNumber: 11
      }, this),
      blog.user && blog.user._id === user.id && /* @__PURE__ */ jsxDEV("button", { onClick: deleteBlog, className: "delete-button", children: "delete" }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 43,
        columnNumber: 54
      }, this)
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 38,
      columnNumber: 19
    }, this)
  ] }, void 0, true, {
    fileName: "F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 31,
    columnNumber: 10
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.shape({
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
    likes: PropTypes.number,
    user: PropTypes.shape({
      username: PropTypes.string,
      _id: PropTypes.string
    })
  }).isRequired,
  handleLike: PropTypes.func.isRequired,
  handleDelete: PropTypes.func.isRequired,
  user: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string
  }).isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/fullStackopen/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNNOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5DTixPQUFPQSxTQUFTQyxnQkFBZ0I7QUFDaEMsT0FBT0MsZUFBZTtBQUd0QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBS0M7QUFBQUEsRUFBV0M7QUFBQUEsRUFBY0M7QUFBSyxNQUFNO0FBQUFDLEtBQUE7QUFDdkQsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlULFNBQVMsS0FBSztBQUU1QyxRQUFNVSxtQkFBbUJBLE1BQU07QUFDN0JELGVBQVcsQ0FBQ0QsT0FBTztBQUFBLEVBQ3JCO0FBS0EsUUFBTUcsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBRUEsUUFBTUMsV0FBV0EsTUFBTTtBQUNyQkMsWUFBUUMsSUFBSSxZQUFXaEIsS0FBS2lCLEtBQUs7QUFDakNoQixlQUFXRCxJQUFJO0FBQUEsRUFDakI7QUFFQSxRQUFNa0IsYUFBYUEsTUFBTTtBQUN2QixRQUFJQyxPQUFPQyxRQUFTLGdCQUFlcEIsS0FBS2lCLEtBQU0sUUFBT2pCLEtBQUtxQixNQUFPLEdBQUUsR0FBRztBQUNwRW5CLG1CQUFhRixJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLE9BQU9RLFdBQVcsV0FBVSxRQUFRLFdBQVNSLEtBQUtzQixLQUNyRDtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNadEI7QUFBQUEsV0FBS2lCO0FBQUFBLE1BQU07QUFBQSxNQUFLakIsS0FBS3FCO0FBQUFBLFNBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxTQUFTZCxrQkFBa0IsV0FBVSxpQkFDM0NGLG9CQUFVLFNBQVMsVUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ0EsV0FDQyx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsWUFBVztBQUFBO0FBQUEsUUFBTUwsS0FBS3VCO0FBQUFBLFdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxNQUN2Qyx1QkFBQyxTQUFJLFdBQVUsY0FBYTtBQUFBO0FBQUEsUUFBUXZCLEtBQUt3QjtBQUFBQSxXQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStDO0FBQUEsTUFDL0MsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBU1YsVUFBVSxXQUFVLGVBQWMsb0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUNyRSx1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBO0FBQUEsUUFBT2QsS0FBS0csT0FBT0gsS0FBS0csS0FBS3NCLFdBQVc7QUFBQSxXQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtGO0FBQUEsTUFDakZ6QixLQUFLRyxRQUFRSCxLQUFLRyxLQUFLbUIsUUFBUW5CLEtBQUt1QixNQUNuQyx1QkFBQyxZQUFPLFNBQVNSLFlBQVksV0FBVSxpQkFBZ0Isc0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxTQU5qRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBO0FBRUo7QUFBQ2QsR0FsREtMLE1BQUk7QUFBQTRCLEtBQUo1QjtBQXFETkEsS0FBSzZCLFlBQVk7QUFBQSxFQUNmNUIsTUFBTUYsVUFBVStCLE1BQU07QUFBQSxJQUNwQlosT0FBT25CLFVBQVVnQyxPQUFPQztBQUFBQSxJQUN4QlYsUUFBUXZCLFVBQVVnQyxPQUFPQztBQUFBQSxJQUN6QlIsS0FBS3pCLFVBQVVnQyxPQUFPQztBQUFBQSxJQUN0QlAsT0FBTzFCLFVBQVVrQztBQUFBQSxJQUNqQjdCLE1BQU1MLFVBQVUrQixNQUFNO0FBQUEsTUFDcEJKLFVBQVUzQixVQUFVZ0M7QUFBQUEsTUFDcEJSLEtBQUt4QixVQUFVZ0M7QUFBQUEsSUFDakIsQ0FBQztBQUFBLEVBQ0gsQ0FBQyxFQUFFQztBQUFBQSxFQUNIOUIsWUFBWUgsVUFBVW1DLEtBQUtGO0FBQUFBLEVBQzNCN0IsY0FBY0osVUFBVW1DLEtBQUtGO0FBQUFBLEVBQzdCNUIsTUFBTUwsVUFBVStCLE1BQU07QUFBQSxJQUNwQkgsSUFBSTVCLFVBQVVnQyxPQUFPQztBQUFBQSxJQUNyQkcsTUFBTXBDLFVBQVVnQztBQUFBQSxFQUNsQixDQUFDLEVBQUVDO0FBQ0w7QUFHQSxlQUFlaEM7QUFBSSxJQUFBNEI7QUFBQVEsYUFBQVIsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJQcm9wVHlwZXMiLCJCbG9nIiwiYmxvZyIsImhhbmRsZUxpa2UiLCJoYW5kbGVEZWxldGUiLCJ1c2VyIiwiX3MiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsInRvZ2dsZVZpc2liaWxpdHkiLCJibG9nU3R5bGUiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJib3JkZXIiLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsImxpa2VCbG9nIiwiY29uc29sZSIsImxvZyIsInRpdGxlIiwiZGVsZXRlQmxvZyIsIndpbmRvdyIsImNvbmZpcm0iLCJhdXRob3IiLCJfaWQiLCJ1cmwiLCJsaWtlcyIsInVzZXJuYW1lIiwiaWQiLCJfYyIsInByb3BUeXBlcyIsInNoYXBlIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsIm51bWJlciIsImZ1bmMiLCJuYW1lIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcclxuXHJcblxyXG5jb25zdCBCbG9nID0gKHsgYmxvZyxoYW5kbGVMaWtlLGhhbmRsZURlbGV0ZSwgdXNlciB9KSA9PiB7XHJcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XHJcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxyXG4gIH1cclxuXHJcblxyXG5cclxuXHJcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xyXG4gICAgcGFkZGluZ1RvcDogMTAsXHJcbiAgICBwYWRkaW5nTGVmdDogMixcclxuICAgIGJvcmRlcjogJ3NvbGlkJyxcclxuICAgIGJvcmRlcldpZHRoOiAxLFxyXG4gICAgbWFyZ2luQm90dG9tOiA1XHJcbiAgfVxyXG5cclxuICBjb25zdCBsaWtlQmxvZyA9ICgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKCdsaWtlQmxvZycsYmxvZy50aXRsZSlcclxuICAgIGhhbmRsZUxpa2UoYmxvZylcclxuICB9XHJcblxyXG4gIGNvbnN0IGRlbGV0ZUJsb2cgPSAoKSA9PiB7XHJcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYERlbGV0ZSBibG9nIFwiJHtibG9nLnRpdGxlfVwiIGJ5ICR7YmxvZy5hdXRob3J9P2ApKSB7XHJcbiAgICAgIGhhbmRsZURlbGV0ZShibG9nKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e2Jsb2dTdHlsZX0gY2xhc3NOYW1lPVwiYmxvZ1wiICBkYXRhLWlkPXtibG9nLl9pZH0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy10aXRsZVwiPlxyXG4gICAgICAgIHtibG9nLnRpdGxlfSBieSB7YmxvZy5hdXRob3J9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9IGNsYXNzTmFtZT1cInRvZ2dsZS1idXR0b25cIj5cclxuICAgICAgIHt2aXNpYmxlID8gJ2hpZGUnIDogJ3ZpZXcnfVxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgICAge3Zpc2libGUgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZy1kZXRhaWxzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXVybFwiPlVSTDoge2Jsb2cudXJsfTwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLWxpa2VzXCI+bGlrZXM6IHtibG9nLmxpa2VzfTwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17bGlrZUJsb2d9IGNsYXNzTmFtZT1cImxpa2UtYnV0dG9uXCI+bGlrZTwvYnV0dG9uPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nLXVzZXJcIj5Vc2VyOiB7YmxvZy51c2VyID8gYmxvZy51c2VyLnVzZXJuYW1lIDogJ1Vua25vd24gVXNlcid9PC9kaXY+XHJcbiAgICAgICAgICB7YmxvZy51c2VyICYmIGJsb2cudXNlci5faWQgPT09IHVzZXIuaWQgJiYgKFxyXG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2RlbGV0ZUJsb2d9IGNsYXNzTmFtZT1cImRlbGV0ZS1idXR0b25cIj5kZWxldGU8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcblxyXG5CbG9nLnByb3BUeXBlcyA9IHtcclxuICBibG9nOiBQcm9wVHlwZXMuc2hhcGUoe1xyXG4gICAgdGl0bGU6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcclxuICAgIGF1dGhvcjogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxyXG4gICAgdXJsOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXHJcbiAgICBsaWtlczogUHJvcFR5cGVzLm51bWJlcixcclxuICAgIHVzZXI6IFByb3BUeXBlcy5zaGFwZSh7XHJcbiAgICAgIHVzZXJuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgICBfaWQ6IFByb3BUeXBlcy5zdHJpbmcsXHJcbiAgICB9KSxcclxuICB9KS5pc1JlcXVpcmVkLFxyXG4gIGhhbmRsZUxpa2U6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXHJcbiAgaGFuZGxlRGVsZXRlOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxyXG4gIHVzZXI6IFByb3BUeXBlcy5zaGFwZSh7XHJcbiAgICBpZDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxyXG4gICAgbmFtZTogUHJvcFR5cGVzLnN0cmluZyxcclxuICB9KS5pc1JlcXVpcmVkLFxyXG59XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiRjovZnVsbFN0YWNrb3Blbi9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9