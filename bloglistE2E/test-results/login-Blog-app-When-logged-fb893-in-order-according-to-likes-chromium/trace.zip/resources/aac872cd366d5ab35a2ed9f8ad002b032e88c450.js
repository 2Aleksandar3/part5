import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2110a278"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/fullStackopen/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2110a278"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx?t=1730739320755";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import Notification from "/src/components/notification.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [errorMessage, setErrorMessage] = useState(null);
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState({
    message: "",
    type: ""
  });
  const [newBlogVisible, setNewBlogVisible] = useState(false);
  useEffect(() => {
    blogService.getAll().then((blogs2) => {
      console.log("Fetched blogs:", blogs2);
      setBlogs(blogs2);
    });
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    console.log("LoginForm re-rendered");
    console.log("Username:", username);
    console.log("Password:", password);
  }, [username, password]);
  const showNotification = (message, type) => {
    setNotification({
      message,
      type
    });
    setTimeout(() => {
      setNotification({
        message: "",
        type: ""
      });
    }, 5e3);
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    console.log("Attempting login with:", username, password);
    try {
      console.log("Logging in with:", username, password);
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      console.log("User when login ", user2);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.error("Login error:", exception);
      setErrorMessage("Wrong credentials");
      showNotification("Wrong credentials", "error");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleLike = async (blog) => {
    const updatedBlog = {
      ...blog,
      likes: blog.likes + 1,
      //Increment likes
      user: blog.user.id
    };
    console.log("trying different blog users", blog.user._id, blog.user.id, blog.user.username);
    try {
      const returnedBlog = await blogService.update(updatedBlog);
      setBlogs(blogs.map((b) => b.id === returnedBlog.id ? returnedBlog : b));
      showNotification("Blog liked successfully", "success");
      console.log("Returned blog:", returnedBlog);
    } catch (exception) {
      console.error("Error liking blog:", exception);
      setErrorMessage("Error liking blog");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleDelete = async (blog) => {
    try {
      await blogService.deleteBlog(blog.id);
      setBlogs(blogs.filter((b) => b.id !== blog.id));
      showNotification(`Blog "${blog.title}" deleted successfully`, "success");
    } catch (exception) {
      console.error("Error deleting blog:", exception);
      setErrorMessage("Error deleting blog");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const addBlog = async ({
    title,
    author,
    url
  }) => {
    console.log("Add blog button clicked");
    try {
      const newBlog = {
        title,
        author,
        url,
        user: user.id
      };
      console.log("New blog data:", newBlog);
      const returnedBlog = await blogService.create(newBlog);
      setBlogs(blogs.concat(returnedBlog));
      showNotification("Blog added successfully", "success");
    } catch (exception) {
      console.error("Error adding blog:", exception);
      setErrorMessage("Error adding blog");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogappUser");
    blogService.setToken(null);
    setUser(null);
  };
  const newBlogForm = () => {
    const hideWhenVisible = {
      display: newBlogVisible ? "none" : ""
    };
    const showWhenVisible = {
      display: newBlogVisible ? "" : "none"
    };
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "add new blog" }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
        lineNumber: 147,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setNewBlogVisible(true), children: "add blog" }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
        lineNumber: 149,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
        lineNumber: 148,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
        /* @__PURE__ */ jsxDEV(BlogForm, { showNotification, addBlog }, void 0, false, {
          fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
          lineNumber: 152,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setNewBlogVisible(false), children: "cancel" }, void 0, false, {
          fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
          lineNumber: 153,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
        lineNumber: 151,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
      lineNumber: 146,
      columnNumber: 12
    }, this);
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
        lineNumber: 159,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
        lineNumber: 160,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          "username:",
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: username, name: "Username", onChange: ({
            target
          }) => {
            console.log("Username input changed to:", target.value), setUsername(target.value);
          } }, void 0, false, {
            fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
            lineNumber: 164,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
          lineNumber: 162,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          "password:",
          /* @__PURE__ */ jsxDEV("input", { type: "password", value: password, name: "Password", onChange: ({
            target
          }) => setPassword(target.value) }, void 0, false, {
            fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
            lineNumber: 173,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
          lineNumber: 171,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
          fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
          lineNumber: 177,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
        lineNumber: 161,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
      lineNumber: 158,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Notification, { message: notification.message, type: notification.type }, void 0, false, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
      lineNumber: 182,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
      lineNumber: 183,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      user.name,
      " logged-in"
    ] }, void 0, true, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
      lineNumber: 184,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Log out" }, void 0, false, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
      lineNumber: 185,
      columnNumber: 7
    }, this),
    newBlogForm(),
    blogs.sort((a, b) => b.likes - a.likes).map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, handleLike, handleDelete, user: blog.user }, blog.id, false, {
      fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
      lineNumber: 187,
      columnNumber: 60
    }, this))
  ] }, void 0, true, {
    fileName: "F:/fullStackopen/bloglist-frontend/src/App.jsx",
    lineNumber: 181,
    columnNumber: 10
  }, this);
};
_s(App, "j/q/2zWXax2r4ZehM49TLAwIyhw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/fullStackopen/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0pNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRKTixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxjQUFjO0FBRXJCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVYsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ1csVUFBVUMsV0FBVyxJQUFJWixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDYSxjQUFjQyxlQUFlLElBQUlkLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNlLFVBQVVDLFdBQVcsSUFBSWhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpQixNQUFNQyxPQUFPLElBQUlsQixTQUFTLElBQUk7QUFDckMsUUFBTSxDQUFDbUIsY0FBY0MsZUFBZSxJQUFJcEIsU0FBUztBQUFBLElBQUVxQixTQUFTO0FBQUEsSUFBSUMsTUFBTTtBQUFBLEVBQUcsQ0FBQztBQUMxRSxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUl4QixTQUFTLEtBQUs7QUFFMURDLFlBQVUsTUFBTTtBQUNkRSxnQkFBWXNCLE9BQU8sRUFBRUMsS0FBS2pCLFlBQVM7QUFDakNrQixjQUFRQyxJQUFJLGtCQUFrQm5CLE1BQUs7QUFDbkNDLGVBQVVELE1BQU07QUFBQSxJQUNsQixDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUU7QUFFTFIsWUFBVSxNQUFNO0FBQ2QsVUFBTTRCLGlCQUFpQkMsT0FBT0MsYUFBYUMsUUFBUSxtQkFBbUI7QUFDdEUsUUFBSUgsZ0JBQWdCO0FBQ2xCLFlBQU1aLFFBQU9nQixLQUFLQyxNQUFNTCxjQUFjO0FBQ3RDWCxjQUFRRCxLQUFJO0FBQ1pkLGtCQUFZZ0MsU0FBU2xCLE1BQUttQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMbkMsWUFBVSxNQUFNO0FBQ2QwQixZQUFRQyxJQUFJLHVCQUF1QjtBQUNuQ0QsWUFBUUMsSUFBSSxhQUFhakIsUUFBUTtBQUNqQ2dCLFlBQVFDLElBQUksYUFBYWIsUUFBUTtBQUFBLEVBQ25DLEdBQUcsQ0FBQ0osVUFBVUksUUFBUSxDQUFDO0FBRXZCLFFBQU1zQixtQkFBbUJBLENBQUNoQixTQUFTQyxTQUFTO0FBQzFDRixvQkFBZ0I7QUFBQSxNQUFFQztBQUFBQSxNQUFTQztBQUFBQSxJQUFLLENBQUM7QUFDakNnQixlQUFXLE1BQU07QUFDZmxCLHNCQUFnQjtBQUFBLFFBQUVDLFNBQVM7QUFBQSxRQUFJQyxNQUFNO0FBQUEsTUFBRyxDQUFDO0FBQUEsSUFDM0MsR0FBRyxHQUFJO0FBQUEsRUFDVDtBQUtBLFFBQU1pQixjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckJkLFlBQVFDLElBQUksMEJBQTBCakIsVUFBVUksUUFBUTtBQUV4RCxRQUFJO0FBQ0ZZLGNBQVFDLElBQUksb0JBQW9CakIsVUFBVUksUUFBUTtBQUNsRCxZQUFNRSxRQUFPLE1BQU1iLGFBQWFzQyxNQUFNO0FBQUEsUUFDcEMvQjtBQUFBQSxRQUFVSTtBQUFBQSxNQUNaLENBQUM7QUFFRGUsYUFBT0MsYUFBYVksUUFDbEIscUJBQXFCVixLQUFLVyxVQUFVM0IsS0FBSSxDQUMxQztBQUVBZCxrQkFBWWdDLFNBQVNsQixNQUFLbUIsS0FBSztBQUMvQlQsY0FBUUMsSUFBSSxvQkFBbUJYLEtBQUk7QUFFbkNDLGNBQVFELEtBQUk7QUFDWkwsa0JBQVksRUFBRTtBQUNkSSxrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBUzZCLFdBQVc7QUFDbEJsQixjQUFRbUIsTUFBTSxnQkFBZ0JELFNBQVM7QUFDdkMvQixzQkFBZ0IsbUJBQW1CO0FBQ25DdUIsdUJBQWlCLHFCQUFxQixPQUFPO0FBQzdDQyxpQkFBVyxNQUFNO0FBQ2Z4Qix3QkFBZ0IsSUFBSTtBQUFBLE1BRXRCLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBR0EsUUFBTWlDLGFBQWEsT0FBT0MsU0FBUztBQUNqQyxVQUFNQyxjQUFjO0FBQUEsTUFDbEIsR0FBR0Q7QUFBQUEsTUFDSEUsT0FBT0YsS0FBS0UsUUFBUTtBQUFBO0FBQUEsTUFDcEJqQyxNQUFLK0IsS0FBSy9CLEtBQUtrQztBQUFBQSxJQUNqQjtBQUNBeEIsWUFBUUMsSUFBSSwrQkFBOEJvQixLQUFLL0IsS0FBS21DLEtBQUtKLEtBQUsvQixLQUFLa0MsSUFBR0gsS0FBSy9CLEtBQUtOLFFBQVE7QUFFeEYsUUFBSTtBQUNGLFlBQU0wQyxlQUFlLE1BQU1sRCxZQUFZbUQsT0FBT0wsV0FBVztBQUN6RHZDLGVBQVNELE1BQU04QyxJQUFJQyxPQUFNQSxFQUFFTCxPQUFPRSxhQUFhRixLQUFLRSxlQUFlRyxDQUFFLENBQUM7QUFDdEVuQix1QkFBaUIsMkJBQTJCLFNBQVM7QUFDckRWLGNBQVFDLElBQUksa0JBQWtCeUIsWUFBWTtBQUFBLElBQzVDLFNBQVNSLFdBQVc7QUFDbEJsQixjQUFRbUIsTUFBTSxzQkFBc0JELFNBQVM7QUFDN0MvQixzQkFBZ0IsbUJBQW1CO0FBQ25Dd0IsaUJBQVcsTUFBTTtBQUNmeEIsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixHQUFHLEdBQUk7QUFBQSxJQUNUO0FBQUEsRUFFRjtBQUVBLFFBQU0yQyxlQUFlLE9BQU9ULFNBQVM7QUFDbkMsUUFBSTtBQUNGLFlBQU03QyxZQUFZdUQsV0FBV1YsS0FBS0csRUFBRTtBQUNwQ3pDLGVBQVNELE1BQU1rRCxPQUFPSCxPQUFLQSxFQUFFTCxPQUFPSCxLQUFLRyxFQUFFLENBQUM7QUFDNUNkLHVCQUFrQixTQUFRVyxLQUFLWSxLQUFNLDBCQUF5QixTQUFTO0FBQUEsSUFDekUsU0FBU2YsV0FBVztBQUNsQmxCLGNBQVFtQixNQUFNLHdCQUF3QkQsU0FBUztBQUMvQy9CLHNCQUFnQixxQkFBcUI7QUFDckN3QixpQkFBVyxNQUFNO0FBQ2Z4Qix3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBR0EsUUFBTStDLFVBQVUsT0FBTztBQUFBLElBQUVEO0FBQUFBLElBQU1FO0FBQUFBLElBQU9DO0FBQUFBLEVBQUksTUFBTTtBQUU5Q3BDLFlBQVFDLElBQUkseUJBQXlCO0FBRXJDLFFBQUk7QUFDRixZQUFNb0MsVUFBVTtBQUFBLFFBQUVKO0FBQUFBLFFBQU9FO0FBQUFBLFFBQVFDO0FBQUFBLFFBQUs5QyxNQUFLQSxLQUFLa0M7QUFBQUEsTUFBSTtBQUNwRHhCLGNBQVFDLElBQUksa0JBQWtCb0MsT0FBTztBQUNyQyxZQUFNWCxlQUFlLE1BQU1sRCxZQUFZOEQsT0FBT0QsT0FBTztBQUNyRHRELGVBQVNELE1BQU15RCxPQUFPYixZQUFZLENBQUM7QUFFbkNoQix1QkFBaUIsMkJBQTJCLFNBQVM7QUFBQSxJQUN2RCxTQUFTUSxXQUFXO0FBQ2xCbEIsY0FBUW1CLE1BQU0sc0JBQXNCRCxTQUFTO0FBQzdDL0Isc0JBQWdCLG1CQUFtQjtBQUNuQ3dCLGlCQUFXLE1BQU07QUFDZnhCLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFJQSxRQUFNcUQsZUFBZUEsTUFBTTtBQUN6QnJDLFdBQU9DLGFBQWFxQyxXQUFXLG1CQUFtQjtBQUNsRGpFLGdCQUFZZ0MsU0FBUyxJQUFJO0FBQ3pCakIsWUFBUSxJQUFJO0FBQUEsRUFBQztBQUVmLFFBQU1tRCxjQUFjQSxNQUFNO0FBQ3hCLFVBQU1DLGtCQUFrQjtBQUFBLE1BQUVDLFNBQVNoRCxpQkFBaUIsU0FBUztBQUFBLElBQUc7QUFDaEUsVUFBTWlELGtCQUFrQjtBQUFBLE1BQUVELFNBQVNoRCxpQkFBaUIsS0FBSztBQUFBLElBQU87QUFDaEUsV0FBTyx1QkFBQyxTQUNOO0FBQUEsNkJBQUMsUUFBRyw0QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdCO0FBQUEsTUFDaEIsdUJBQUMsU0FBSSxPQUFPK0MsaUJBQ1YsaUNBQUMsWUFBTyxTQUFTLE1BQU05QyxrQkFBa0IsSUFBSSxHQUFHLHdCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdELEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPZ0QsaUJBQ1Y7QUFBQSwrQkFBQyxZQUNDLGtCQUVBLFdBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdtQjtBQUFBLFFBQ25CLHVCQUFDLFlBQU8sU0FBUyxNQUFNaEQsa0JBQWtCLEtBQUssR0FBRyxzQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFdBTHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBWEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlQO0FBQUEsRUFDRjtBQUVBLE1BQUlQLFNBQVMsTUFBTTtBQUNqQixXQUNFLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxnQkFBYSxTQUFTRSxhQUFhRSxTQUFTLE1BQU1GLGFBQWFHLFFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUNyRSx1QkFBQyxRQUFHLHFDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxVQUFLLFVBQVVpQixhQUNkO0FBQUEsK0JBQUMsU0FBSTtBQUFBO0FBQUEsVUFFSCx1QkFBQyxXQUNDLE1BQUssUUFDTCxPQUFPNUIsVUFDUCxNQUFLLFlBQ0wsVUFBVSxDQUFDO0FBQUEsWUFBRThEO0FBQUFBLFVBQU8sTUFBTTtBQUFDOUMsb0JBQVFDLElBQUksOEJBQThCNkMsT0FBT0MsS0FBSyxHQUFHOUQsWUFBWTZELE9BQU9DLEtBQUs7QUFBQSxVQUFDLEtBSi9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSWlIO0FBQUEsYUFObkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxVQUVILHVCQUFDLFdBQ0MsTUFBSyxZQUNMLE9BQU8zRCxVQUNQLE1BQUssWUFDTCxVQUFVLENBQUM7QUFBQSxZQUFFMEQ7QUFBQUEsVUFBTyxNQUFNekQsWUFBWXlELE9BQU9DLEtBQUssS0FKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJc0Q7QUFBQSxhQU54RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsV0FwQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLGdCQUFhLFNBQVN2RCxhQUFhRSxTQUFTLE1BQU1GLGFBQWFHLFFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUU7QUFBQSxJQUNyRSx1QkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsT0FBR0w7QUFBQUEsV0FBSzBEO0FBQUFBLE1BQUs7QUFBQSxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUN4Qix1QkFBQyxZQUFPLFNBQVNSLGNBQWMsdUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0M7QUFBQSxJQUNyQ0UsWUFBWTtBQUFBLElBQ1o1RCxNQUFNbUUsS0FBSyxDQUFDQyxHQUFHckIsTUFBTUEsRUFBRU4sUUFBUTJCLEVBQUUzQixLQUFLLEVBQUVLLElBQUlQLFVBQzNDLHVCQUFDLFFBQW1CLE1BQVksWUFBd0IsY0FBNEIsTUFBTUEsS0FBSy9CLFFBQXBGK0IsS0FBS0csSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRyxDQUN0RztBQUFBLE9BUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBR0o7QUFBQzNDLEdBek1LRCxLQUFHO0FBQUF1RSxLQUFIdkU7QUEyTU4sZUFBZUE7QUFBRyxJQUFBdUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiQmxvZyIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiTm90aWZpY2F0aW9uIiwiQmxvZ0Zvcm0iLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibm90aWZpY2F0aW9uIiwic2V0Tm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInR5cGUiLCJuZXdCbG9nVmlzaWJsZSIsInNldE5ld0Jsb2dWaXNpYmxlIiwiZ2V0QWxsIiwidGhlbiIsImNvbnNvbGUiLCJsb2ciLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwic2hvd05vdGlmaWNhdGlvbiIsInNldFRpbWVvdXQiLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJlcnJvciIsImhhbmRsZUxpa2UiLCJibG9nIiwidXBkYXRlZEJsb2ciLCJsaWtlcyIsImlkIiwiX2lkIiwicmV0dXJuZWRCbG9nIiwidXBkYXRlIiwibWFwIiwiYiIsImhhbmRsZURlbGV0ZSIsImRlbGV0ZUJsb2ciLCJmaWx0ZXIiLCJ0aXRsZSIsImFkZEJsb2ciLCJhdXRob3IiLCJ1cmwiLCJuZXdCbG9nIiwiY3JlYXRlIiwiY29uY2F0IiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsIm5ld0Jsb2dGb3JtIiwiaGlkZVdoZW5WaXNpYmxlIiwiZGlzcGxheSIsInNob3dXaGVuVmlzaWJsZSIsInRhcmdldCIsInZhbHVlIiwibmFtZSIsInNvcnQiLCJhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXHJcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xyXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nXHJcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL25vdGlmaWNhdGlvbidcclxuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcclxuXHJcbmNvbnN0IEFwcCA9ICgpID0+IHtcclxuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxyXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2Vycm9yTWVzc2FnZSwgc2V0RXJyb3JNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFtub3RpZmljYXRpb24sIHNldE5vdGlmaWNhdGlvbl0gPSB1c2VTdGF0ZSh7IG1lc3NhZ2U6ICcnLCB0eXBlOiAnJyB9KVxyXG4gIGNvbnN0IFtuZXdCbG9nVmlzaWJsZSwgc2V0TmV3QmxvZ1Zpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ0ZldGNoZWQgYmxvZ3M6JywgYmxvZ3MpXHJcbiAgICAgIHNldEJsb2dzKCBibG9ncyApXHJcbiAgICB9KVxyXG4gIH0sIFtdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgbG9nZ2VkVXNlckpTT04gPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvZ2dlZEJsb2dhcHBVc2VyJylcclxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xyXG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcclxuICAgICAgc2V0VXNlcih1c2VyKVxyXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxyXG4gICAgfVxyXG4gIH0sIFtdKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coJ0xvZ2luRm9ybSByZS1yZW5kZXJlZCcpXHJcbiAgICBjb25zb2xlLmxvZygnVXNlcm5hbWU6JywgdXNlcm5hbWUpXHJcbiAgICBjb25zb2xlLmxvZygnUGFzc3dvcmQ6JywgcGFzc3dvcmQpXHJcbiAgfSwgW3VzZXJuYW1lLCBwYXNzd29yZF0pXHJcblxyXG4gIGNvbnN0IHNob3dOb3RpZmljYXRpb24gPSAobWVzc2FnZSwgdHlwZSkgPT4ge1xyXG4gICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZSwgdHlwZSB9KVxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IG1lc3NhZ2U6ICcnLCB0eXBlOiAnJyB9KVxyXG4gICAgfSwgNTAwMCkgLy8gTm90aWZpY2F0aW9uIGRpc2FwcGVhcnMgYWZ0ZXIgNSBzZWNvbmRzXHJcbiAgfVxyXG5cclxuXHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG5cclxuICAgIGNvbnNvbGUubG9nKCdBdHRlbXB0aW5nIGxvZ2luIHdpdGg6JywgdXNlcm5hbWUsIHBhc3N3b3JkKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdMb2dnaW5nIGluIHdpdGg6JywgdXNlcm5hbWUsIHBhc3N3b3JkKVxyXG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKHtcclxuICAgICAgICB1c2VybmFtZSwgcGFzc3dvcmQsXHJcbiAgICAgIH0pXHJcblxyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXHJcbiAgICAgICAgJ2xvZ2dlZEJsb2dhcHBVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcilcclxuICAgICAgKVxyXG5cclxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcclxuICAgICAgY29uc29sZS5sb2coJ1VzZXIgd2hlbiBsb2dpbiAnLHVzZXIpXHJcblxyXG4gICAgICBzZXRVc2VyKHVzZXIpXHJcbiAgICAgIHNldFVzZXJuYW1lKCcnKVxyXG4gICAgICBzZXRQYXNzd29yZCgnJylcclxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdMb2dpbiBlcnJvcjonLCBleGNlcHRpb24pXHJcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnV3JvbmcgY3JlZGVudGlhbHMnKVxyXG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdXcm9uZyBjcmVkZW50aWFscycsICdlcnJvcicpXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxyXG5cclxuICAgICAgfSwgNTAwMClcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVMaWtlID0gYXN5bmMgKGJsb2cpID0+IHtcclxuICAgIGNvbnN0IHVwZGF0ZWRCbG9nID0ge1xyXG4gICAgICAuLi5ibG9nLFxyXG4gICAgICBsaWtlczogYmxvZy5saWtlcyArIDEsICAvL0luY3JlbWVudCBsaWtlc1xyXG4gICAgICB1c2VyOmJsb2cudXNlci5pZCxcclxuICAgIH1cclxuICAgIGNvbnNvbGUubG9nKCd0cnlpbmcgZGlmZmVyZW50IGJsb2cgdXNlcnMnLGJsb2cudXNlci5faWQgLGJsb2cudXNlci5pZCxibG9nLnVzZXIudXNlcm5hbWUpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmV0dXJuZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlKHVwZGF0ZWRCbG9nKSAvLyBDYWxsIHRoZSB1cGRhdGUgZnVuY3Rpb25cclxuICAgICAgc2V0QmxvZ3MoYmxvZ3MubWFwKGIgPT4gKGIuaWQgPT09IHJldHVybmVkQmxvZy5pZCA/IHJldHVybmVkQmxvZyA6IGIpKSkgLy8gVXBkYXRlIHRoZSBzdGF0ZVxyXG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdCbG9nIGxpa2VkIHN1Y2Nlc3NmdWxseScsICdzdWNjZXNzJylcclxuICAgICAgY29uc29sZS5sb2coJ1JldHVybmVkIGJsb2c6JywgcmV0dXJuZWRCbG9nKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxpa2luZyBibG9nOicsIGV4Y2VwdGlvbilcclxuICAgICAgc2V0RXJyb3JNZXNzYWdlKCdFcnJvciBsaWtpbmcgYmxvZycpXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxyXG4gICAgICB9LCA1MDAwKVxyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChibG9nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBibG9nU2VydmljZS5kZWxldGVCbG9nKGJsb2cuaWQpXHJcbiAgICAgIHNldEJsb2dzKGJsb2dzLmZpbHRlcihiID0+IGIuaWQgIT09IGJsb2cuaWQpKVxyXG4gICAgICBzaG93Tm90aWZpY2F0aW9uKGBCbG9nIFwiJHtibG9nLnRpdGxlfVwiIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5YCwgJ3N1Y2Nlc3MnKVxyXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGRlbGV0aW5nIGJsb2c6JywgZXhjZXB0aW9uKVxyXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ0Vycm9yIGRlbGV0aW5nIGJsb2cnKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcclxuICAgICAgfSwgNTAwMClcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICBjb25zdCBhZGRCbG9nID0gYXN5bmMgKHsgdGl0bGUsYXV0aG9yLHVybCB9KSA9PiB7XHJcblxyXG4gICAgY29uc29sZS5sb2coJ0FkZCBibG9nIGJ1dHRvbiBjbGlja2VkJylcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBuZXdCbG9nID0geyB0aXRsZSwgYXV0aG9yLCB1cmwgLHVzZXI6dXNlci5pZCwgfVxyXG4gICAgICBjb25zb2xlLmxvZygnTmV3IGJsb2cgZGF0YTonLCBuZXdCbG9nKVxyXG4gICAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUobmV3QmxvZylcclxuICAgICAgc2V0QmxvZ3MoYmxvZ3MuY29uY2F0KHJldHVybmVkQmxvZykpXHJcblxyXG4gICAgICBzaG93Tm90aWZpY2F0aW9uKCdCbG9nIGFkZGVkIHN1Y2Nlc3NmdWxseScsICdzdWNjZXNzJylcclxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhZGRpbmcgYmxvZzonLCBleGNlcHRpb24pXHJcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnRXJyb3IgYWRkaW5nIGJsb2cnKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcclxuICAgICAgfSwgNTAwMClcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuXHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXHJcbiAgICBibG9nU2VydmljZS5zZXRUb2tlbihudWxsKSAvLyBPcHRpb25hbGx5IGNsZWFyIHRoZSB0b2tlbiBmcm9tIGJsb2dTZXJ2aWNlXHJcbiAgICBzZXRVc2VyKG51bGwpfVxyXG5cclxuICBjb25zdCBuZXdCbG9nRm9ybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogbmV3QmxvZ1Zpc2libGUgPyAnbm9uZScgOiAnJyB9XHJcbiAgICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IG5ld0Jsb2dWaXNpYmxlID8gJycgOiAnbm9uZScgfVxyXG4gICAgcmV0dXJuKDxkaXY+XHJcbiAgICAgIDxoMj5hZGQgbmV3IGJsb2c8L2gyPlxyXG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0TmV3QmxvZ1Zpc2libGUodHJ1ZSl9PmFkZCBibG9nPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IHN0eWxlPXtzaG93V2hlblZpc2libGV9PlxyXG4gICAgICAgIDxCbG9nRm9ybVxyXG4gICAgICAgICAgc2hvd05vdGlmaWNhdGlvbj17c2hvd05vdGlmaWNhdGlvbn1cclxuXHJcbiAgICAgICAgICBhZGRCbG9nPXthZGRCbG9nfSAvPlxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0TmV3QmxvZ1Zpc2libGUoZmFsc2UpfT5jYW5jZWw8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj4pXHJcbiAgfVxyXG5cclxuICBpZiAodXNlciA9PT0gbnVsbCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e25vdGlmaWNhdGlvbi5tZXNzYWdlfSB0eXBlPXtub3RpZmljYXRpb24udHlwZX0gLz5cclxuICAgICAgICA8aDI+TG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgIHVzZXJuYW1lOlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJVc2VybmFtZVwiXHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiB7Y29uc29sZS5sb2coJ1VzZXJuYW1lIGlucHV0IGNoYW5nZWQgdG86JywgdGFyZ2V0LnZhbHVlKSwgc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX19XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgcGFzc3dvcmQ6XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5sb2dpbjwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPE5vdGlmaWNhdGlvbiBtZXNzYWdlPXtub3RpZmljYXRpb24ubWVzc2FnZX0gdHlwZT17bm90aWZpY2F0aW9uLnR5cGV9IC8+XHJcbiAgICAgIDxoMj5ibG9nczwvaDI+XHJcbiAgICAgIDxwPnt1c2VyLm5hbWV9IGxvZ2dlZC1pbjwvcD5cclxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PkxvZyBvdXQ8L2J1dHRvbj5cclxuICAgICAge25ld0Jsb2dGb3JtKCl9XHJcbiAgICAgIHtibG9ncy5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcykubWFwKGJsb2cgPT5cclxuICAgICAgICA8QmxvZyBrZXk9e2Jsb2cuaWR9IGJsb2c9e2Jsb2d9IGhhbmRsZUxpa2U9e2hhbmRsZUxpa2V9IGhhbmRsZURlbGV0ZT17aGFuZGxlRGVsZXRlfSB1c2VyPXtibG9nLnVzZXJ9IC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHBcclxuXHJcbiJdLCJmaWxlIjoiRjovZnVsbFN0YWNrb3Blbi9ibG9nbGlzdC1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9