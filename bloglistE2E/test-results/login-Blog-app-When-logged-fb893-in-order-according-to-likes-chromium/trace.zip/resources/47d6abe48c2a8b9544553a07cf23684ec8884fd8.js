import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2110a278"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/fullStackopen/bloglist-frontend/src/components/notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=2110a278"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=2110a278"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Notification = ({
  message,
  type
}) => {
  if (!message)
    return null;
  const notificationStyle = {
    padding: "10px",
    marginBottom: "10px",
    borderRadius: "5px",
    color: "white",
    backgroundColor: type === "error" ? "red" : "green",
    textAlign: "center",
    position: "fixed",
    top: "10px",
    left: "50%",
    transform: "translateX(-50%)",
    zIndex: 1e3
  };
  return /* @__PURE__ */ jsxDEV("div", { style: notificationStyle, children: message }, void 0, false, {
    fileName: "F:/fullStackopen/bloglist-frontend/src/components/notification.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_c = Notification;
Notification.propTypes = {
  message: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired
};
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/fullStackopen/bloglist-frontend/src/components/notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJJO0FBckJKLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixPQUFPQyxlQUFlO0FBRXRCLE1BQU1DLGVBQWVBLENBQUM7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUFLLE1BQU07QUFDMUMsTUFBSSxDQUFDRDtBQUFTLFdBQU87QUFFckIsUUFBTUUsb0JBQW9CO0FBQUEsSUFDeEJDLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsSUFDZEMsY0FBYztBQUFBLElBQ2RDLE9BQU87QUFBQSxJQUNQQyxpQkFBaUJOLFNBQVMsVUFBVSxRQUFRO0FBQUEsSUFDNUNPLFdBQVc7QUFBQSxJQUNYQyxVQUFVO0FBQUEsSUFDVkMsS0FBSztBQUFBLElBQ0xDLE1BQU07QUFBQSxJQUNOQyxXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLEVBQ1Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBT1gsbUJBQ1RGLHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNjLEtBdEJLZjtBQXdCTkEsYUFBYWdCLFlBQVk7QUFBQSxFQUN2QmYsU0FBU0YsVUFBVWtCLE9BQU9DO0FBQUFBLEVBQzFCaEIsTUFBTUgsVUFBVWtCLE9BQU9DO0FBQ3pCO0FBRUEsZUFBZWxCO0FBQVksSUFBQWU7QUFBQUksYUFBQUosSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiUHJvcFR5cGVzIiwiTm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInR5cGUiLCJub3RpZmljYXRpb25TdHlsZSIsInBhZGRpbmciLCJtYXJnaW5Cb3R0b20iLCJib3JkZXJSYWRpdXMiLCJjb2xvciIsImJhY2tncm91bmRDb2xvciIsInRleHRBbGlnbiIsInBvc2l0aW9uIiwidG9wIiwibGVmdCIsInRyYW5zZm9ybSIsInpJbmRleCIsIl9jIiwicHJvcFR5cGVzIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm5vdGlmaWNhdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXHJcblxyXG5jb25zdCBOb3RpZmljYXRpb24gPSAoeyBtZXNzYWdlLCB0eXBlIH0pID0+IHtcclxuICBpZiAoIW1lc3NhZ2UpIHJldHVybiBudWxsXHJcblxyXG4gIGNvbnN0IG5vdGlmaWNhdGlvblN0eWxlID0ge1xyXG4gICAgcGFkZGluZzogJzEwcHgnLFxyXG4gICAgbWFyZ2luQm90dG9tOiAnMTBweCcsXHJcbiAgICBib3JkZXJSYWRpdXM6ICc1cHgnLFxyXG4gICAgY29sb3I6ICd3aGl0ZScsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IHR5cGUgPT09ICdlcnJvcicgPyAncmVkJyA6ICdncmVlbicsXHJcbiAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxyXG4gICAgcG9zaXRpb246ICdmaXhlZCcsXHJcbiAgICB0b3A6ICcxMHB4JyxcclxuICAgIGxlZnQ6ICc1MCUnLFxyXG4gICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlWCgtNTAlKScsXHJcbiAgICB6SW5kZXg6IDEwMDAsXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBzdHlsZT17bm90aWZpY2F0aW9uU3R5bGV9PlxyXG4gICAgICB7bWVzc2FnZX1cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuTm90aWZpY2F0aW9uLnByb3BUeXBlcyA9IHtcclxuICBtZXNzYWdlOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXHJcbiAgdHlwZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb24iXSwiZmlsZSI6IkY6L2Z1bGxTdGFja29wZW4vYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvbm90aWZpY2F0aW9uLmpzeCJ9